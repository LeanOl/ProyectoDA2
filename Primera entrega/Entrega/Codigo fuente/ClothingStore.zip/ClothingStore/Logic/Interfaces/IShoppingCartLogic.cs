﻿using Domain;

namespace Logic.Interfaces
{

    public interface IShoppingCartLogic
    {
        void ApplyBestPromotion(ShoppingCart shoppingCart);
    }
}