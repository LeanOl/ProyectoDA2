﻿namespace APIModels.InputModels
{
    public class ConditionMatchType
    {
        public const string Same = "Same";
        public const string Any = "Any";
    }
}