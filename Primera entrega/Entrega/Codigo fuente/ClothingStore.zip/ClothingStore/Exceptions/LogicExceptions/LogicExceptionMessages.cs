﻿namespace Exceptions.LogicExceptions
{
    public static class LogicExceptionMessages
    {
        public const string InvalidCondition = "The promotion condition is invalid.";

    }
}